</div> <!-- .container sonu -->

<footer style="text-align:center; padding: 20px; margin-top: 20px; background-color: #e9ecef; color: #6c757d;">
    <p>Hatim & İbadet Platformu &copy; <?php echo date('Y'); ?></p>
</footer>

</body>
</html>
